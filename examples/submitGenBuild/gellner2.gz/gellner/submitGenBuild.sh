#!/bin/bash

../../../bin/submitGenBuild -i helix.conf
