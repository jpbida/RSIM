#!/bin/bash

../../../../bin/assembleCons -i assemble_helix.conf
